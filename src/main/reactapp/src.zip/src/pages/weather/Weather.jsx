import React from 'react'

const Weather = () => {
  return (
    <div>Weather</div>
  )
}

export default Weather