import React from 'react'

const TravelDetail = () => {
  return (
    <div>TravelDetail</div>
  )
}

export default TravelDetail