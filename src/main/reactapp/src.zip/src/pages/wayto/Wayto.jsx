import React from 'react'

const Wayto = () => {
  return (
    <div>Wayto</div>
  )
}

export default Wayto